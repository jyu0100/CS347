package app;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.time.LocalTime;

/*
Cruise Control GUI class that calls functions when an
action occurs from a button or menu option
*/
public class CC implements ActionListener {
    // variables to be used and manipulated by functions
    private int carSpeed = 0, CCSpeed = 0;
    private boolean on = false;
    private boolean brakePressed, acceleratePressed;
    private LocalTime time;
    private File logFile = new File("src\\app\\log.txt");
    PrintWriter out;

    // GUI variables
    private JFrame frame;
    private JMenuBar menubar;
    private JMenu menu;
    private JMenuItem log;
    private JLabel onoffLabel;
    private JLabel carSpeedLabel;
    private JLabel CCSpeedLabel;
    private JPanel panel;

    public CC() {
        // Window frame
        frame = new JFrame("Cruise Control");

        // Menu bar
        menubar = new JMenuBar();
        menu = new JMenu("Options");
        log = new JMenuItem("Open log");
        log.addActionListener(this);
        menu.add(log);
        menubar.add(menu);
        frame.setJMenuBar(menubar);

        // Labels
        onoffLabel = new JLabel("Cruise Control:  Off   ");
        carSpeedLabel = new JLabel("Car Speed:  0     ");
        CCSpeedLabel = new JLabel("CC Speed:  0     ");

        // Click Buttons
        @SuppressWarnings("serial")
        JButton increaseSpeed = new JButton(new AbstractAction("Increase CC Speed") {
            @Override
            public void actionPerformed(final ActionEvent e) {
                increaseSpeed();

            }
        });

        @SuppressWarnings("serial")
        JButton decreaseSpeed = new JButton(new AbstractAction("Decrease CC Speed") {
            @Override
            public void actionPerformed(final ActionEvent e) {
                decreaseSpeed();
            }
        });

        @SuppressWarnings("serial")
        JButton onoff_set = new JButton(new AbstractAction("On / Off / Set CC Speed") {
            @Override
            public void actionPerformed(final ActionEvent e) {
                if (on) {
                    turnOffCC(increaseSpeed, decreaseSpeed);
                } else {
                    turnOnCC(increaseSpeed, decreaseSpeed);
                }
            }
        });

        // Press and hold buttons
        JButton accelerate = new JButton("Accelerate");
        accelerate.addMouseListener(new MouseAdapter() {
            public void mousePressed(final MouseEvent e) {
                accelerate();
            }

            public void mouseReleased(final MouseEvent e) {
                acceleratePressed = false;

                // log acceletation
                time = java.time.LocalTime.now();
                try {
                    out = new PrintWriter(new FileWriter(logFile, true));
                    out.append("[" + time + "] User Accelerated Car Speed Upto " + carSpeed +"\n");
                    out.close();
                } catch (IOException e3) {
                }
            }
        });

        JButton brake = new JButton("Brake");
        brake.addMouseListener(new MouseAdapter() {
            public void mousePressed(final MouseEvent e) {
                brake(increaseSpeed, decreaseSpeed);
            }

            public void mouseReleased(final MouseEvent e) {
                brakePressed = false;

                // log deceleration
                if (carSpeed >= 0) {
                    time = java.time.LocalTime.now();
                    try {
                        out = new PrintWriter(new FileWriter(logFile, true));
                        out.append("[" + time + "] User Decelerated Car Speed Upto " + carSpeed +"\n");
                        out.close();
                    } catch (IOException e3) {
                    }
                }

                // if (!on) {
                //     time = java.time.LocalTime.now();
                //     try {
                //         out = new PrintWriter(new FileWriter(logFile, true));
                //         out.append("[" + time + "] Cruise Control Deactivated\n");
                //         out.append("\n");
                //         out.close();
                //     } catch (IOException e4) {
                //     }
                // }
            }
        });

        // disable buttons
        increaseSpeed.setEnabled(false);
        decreaseSpeed.setEnabled(false);

        // Panel settings and add features for GUI
        panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(100, 80, 100, 80));
        panel.setLayout(new GridLayout(0, 1));
        panel.add(onoffLabel);
        panel.add(carSpeedLabel);
        panel.add(CCSpeedLabel);
        panel.add(onoff_set);
        panel.add(accelerate);
        panel.add(brake);
        panel.add(increaseSpeed);
        panel.add(decreaseSpeed);

        // GUI Frame settings
        frame.add(panel, BorderLayout.CENTER);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setResizable(false);
    }

    /*
    Function that turns on the CC if it is in the correct
    range of mph; otherwise displays an error message
    */
    public void turnOnCC(JButton increaseSpeed, JButton decreaseSpeed) {
        // turn on CC
        if (carSpeed >= 25 && carSpeed <= 70) {
            // log that CC turned on
            time = java.time.LocalTime.now();
            try {
                out = new PrintWriter(new FileWriter(logFile, true));
                out.append("[" + time + "] Cruise Control Activated\n");
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            on = true;
            onoffLabel.setText("Cruise Control:  On   ");
            increaseSpeed.setEnabled(true);
            decreaseSpeed.setEnabled(true);
            CCSpeed = carSpeed;
            CCSpeedLabel.setText("CC Speed:  " + CCSpeed);
        } else {
            JOptionPane.showMessageDialog(null, "Cruise Control must be between 25 and 70mph inclusive",
                                         "Error", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /*
    Function that updates the CC speed if the car speed is different;
    otherwise turns off the CC and logs the info on the trip
    */
    public void turnOffCC(JButton increaseSpeed, JButton decreaseSpeed) {
        // update CC speed
        if (on && carSpeed != CCSpeed && !brakePressed) {
            on = true;
            CCSpeed = carSpeed;
            CCSpeedLabel.setText("CC Speed:  " + CCSpeed);

            // log that CC updated speed
            time = java.time.LocalTime.now();
            try {
                out = new PrintWriter(new FileWriter(logFile, true));
                out.append("[" + time + "] Cruise Control Speed Updated to " + CCSpeed + "\n");
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        // turn off CC
        else {
            // log that CC turned off
            if (on) {
                time = java.time.LocalTime.now();
                try {
                    out = new PrintWriter(new FileWriter(logFile, true));
                    out.append("[" + time + "] Cruise Control Deactivated\n");
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            
            on = false;
            onoffLabel.setText("Cruise Control:  Off   ");
            increaseSpeed.setEnabled(false);
            decreaseSpeed.setEnabled(false);
            CCSpeed = 0;
            CCSpeedLabel.setText("CC Speed:  " + CCSpeed);
            
        }
    }

    /*
    Function that accelerates the car speed by one when button
    pressed or continuously while the button is held down
    */
    public void accelerate() {
        acceleratePressed = true;
        new Thread() {
            public void run() {
                while (acceleratePressed) {
                    carSpeed += 1;
                    carSpeedLabel.setText("Car Speed:  " + carSpeed);
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    /*
    Function that turns off the CC and decelerates the car speed by one
    when button pressed or continuously while the button is held down
    */
    public void brake(JButton increaseSpeed, JButton decreaseSpeed) {
        brakePressed = true;
        turnOffCC(increaseSpeed, decreaseSpeed);
        new Thread() {
            public void run() {
                while (brakePressed && carSpeed > 0) {
                    carSpeed -= 1;
                    carSpeedLabel.setText("Car Speed:  " + carSpeed);
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    /*
    Function that increases both the CC speed and car speed if they
    are the same; otherwise increases the CC speed indepently
    */
    public void increaseSpeed() {
        if (carSpeed < 70 && CCSpeed < 70) {
            if (carSpeed == CCSpeed) {
                carSpeed++;
                CCSpeed++;
            } else {
                CCSpeed++;
            }

            // log that CC increased speed
            time = java.time.LocalTime.now();
            try {
                out = new PrintWriter(new FileWriter(logFile, true));
                out.append("[" + time + "] Cruise Control speed increased by 1\n");
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        carSpeedLabel.setText("Car Speed:  " + carSpeed);
        CCSpeedLabel.setText("CC Speed:  " + CCSpeed);
    }

    /*
    Function that decreases both the CC speed and car speed if they
    are the same; otherwise decreases the CC speed indepently
    */
    public void decreaseSpeed() {
        if (carSpeed > 25 && CCSpeed > 25) {
            if (carSpeed == CCSpeed) {
                CCSpeed = carSpeed;
                carSpeed--;
                CCSpeed--;
            } else {
                CCSpeed--;
            }
            time = java.time.LocalTime.now();
            try {
                out = new PrintWriter(new FileWriter(logFile, true));
                out.append("[" + time + "] Cruise Control speed decreased by 1\n");
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        carSpeedLabel.setText("Car Speed:  " + carSpeed);
        CCSpeedLabel.setText("CC Speed:  " + CCSpeed);
    }


    /*
    Function that opens the log text file
    when the menu option is pressed
    */
    public void actionPerformed(final ActionEvent e) {
        // create log text file if not already created
        try {
            File log = new File("src\\app\\log.txt");
            log.createNewFile();
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        // open log text file in notepad
        ProcessBuilder pb = new ProcessBuilder("Notepad.exe", "src\\app\\log.txt");
        try {
            pb.start();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    public static void main(final String[] args) {
        // clear log text file on startup
        PrintWriter writer;
        try {
            writer = new PrintWriter("src\\app\\log.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
        // create GUI
        new CC();
    }
}